/*************************************************************************
	> File Name: haizei_util.h
	> Author: 
	> Mail: 
	> Created Time: 2020年11月16日 星期一 00时23分09秒
 ************************************************************************/

#ifndef _HAIZEI_UTIL_H
#define _HAIZEI_UTIL_H
#include <string>
namespace haizei{
std::string ConvertStringToCString(const std::string &);

}

#endif
